//
//  replayViewController.swift
//  ShooterGame
//
//  Created by il17aag on 11/01/2020.
//  Copyright © 2020 il17aag. All rights reserved.
//

import UIKit

class replayViewController: UIViewController {

    @IBAction func restart(_ sender: Any) {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let playPage = main.instantiateViewController(identifier: "mainVC")
        self.present(playPage, animated: true, completion: nil)
    }
    @IBAction func starter(_ sender: Any) {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let menuPage = main.instantiateViewController(identifier: "homeVC")
        self.present(menuPage, animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
